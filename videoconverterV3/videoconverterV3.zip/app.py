#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VideoConV3: replace source audio with stereo AC-3/E-AC-3 tracks."""

from __future__ import annotations

import importlib.util
import json
import shutil
import subprocess
import tempfile
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from types import ModuleType

ROOT = Path(__file__).resolve().parent
VIDEO_EXTENSIONS = {".mkv", ".mp4", ".m4v", ".mov", ".ts", ".mts", ".m2ts", ".webm"}
MATRIX_MODES = {
    "Dolby Surround (DS)": "ds",
    "Dolby Pro Logic (DPL)": "pl",
    "Dolby Pro Logic II (DPL2)": "pl2",
    "PLII Simple (DPL2S)": "pl2s",
}
VIDEO_PRESETS = {
    "Copy Video Stream": None,
    "Animate 24fps (Modern Anime)": (
        "crf=31:qpmin=28:qpmax=51:keyint=360:bframes=5:"
        "b-pyramid=1:ref=5:rc-lookahead=48:lookahead-slices=4:"
        "vbv-maxrate=5000:vbv-bufsize=7500:aq-mode=2:aq-strength=1.15:"
        "psy-rd=0.4:psy-rdoq=0.0:deblock=1,1:open-gop=1:weightp=0:wpp=1"
    ),
    "90s MV Tape (มี Noise / Grain)": (
        "crf=31:qpmin=28:qpmax=51:keyint=375:bframes=5:"
        "b-pyramid=1:ref=5:rc-lookahead=40:lookahead-slices=4:"
        "vbv-maxrate=5000:vbv-bufsize=7500:aq-mode=2:aq-strength=0.85:"
        "no-sao=1:psy-rd=1.0:psy-rdoq=1.0:deblock=-1,-1:open-gop=1:"
        "weightp=0:wpp=1"
    ),
    "90s MV Tape (ไม่มี Noise / Clean)": (
        "crf=32:qpmin=30:qpmax=51:keyint=375:bframes=5:"
        "b-pyramid=1:ref=5:rc-lookahead=32:aq-mode=2:aq-strength=1.0:"
        "sao=1:psy-rd=0.7:deblock=0,0:open-gop=1:weightp=0"
    ),
    "Movie / Film 24fps (หนังฟิล์ม / เกรนธรรมชาติ)": (
        "crf=32:qpmin=30:qpmax=51:keyint=360:bframes=5:"
        "b-pyramid=1:ref=5:rc-lookahead=32:aq-mode=2:aq-strength=0.9:"
        "no-sao=1:psy-rd=1.0:psy-rdoq=1.0:deblock=-1,-1:"
        "open-gop=1:weightp=0"
    ),
    "Classic Anime 24fps (อนิเมะคลาสสิก / วาดมือ มีเกรน)": (
        "crf=32:qpmin=30:qpmax=51:keyint=360:bframes=5:"
        "b-pyramid=1:ref=5:rc-lookahead=32:aq-mode=2:aq-strength=1.1:"
        "no-sao=1:psy-rd=0.6:psy-rdoq=0.5:deblock=0,0:"
        "open-gop=1:weightp=0"
    ),
}


class AppError(RuntimeError):
    """An expected, user-facing application error."""


def load_module(name: str) -> ModuleType:
    path = ROOT / f"{name}.py"
    spec = importlib.util.spec_from_file_location(f"_v3_{name}", path)
    if spec is None or spec.loader is None:
        raise AppError(f"โหลดโมดูลไม่สำเร็จ: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def executable(name: str) -> str:
    value = shutil.which(name) or shutil.which(f"{name}.exe")
    if not value:
        raise AppError(f"ไม่พบ {name}.exe ใน PATH")
    return value


def optional_executable(name: str) -> str | None:
    return shutil.which(name) or shutil.which(f"{name}.exe")


def run(command: list[str], *, label: str) -> None:
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode:
        detail = (result.stderr or result.stdout).strip()
        raise AppError(f"{label} ล้มเหลว:\n{detail[-3000:]}")


def probe_audio(ffprobe: str, source: Path) -> list[dict]:
    command = [
        ffprobe, "-v", "error", "-show_entries",
        "stream=index,codec_name,channels,channel_layout:stream_tags=language,title",
        "-select_streams", "a", "-of", "json", str(source),
    ]
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode:
        raise AppError(f"อ่าน audio stream ไม่สำเร็จ:\n{result.stderr.strip()}")
    return json.loads(result.stdout or "{}").get("streams", [])


def normalized_language(info: dict, ordinal: int, fallback: tuple[str, str]) -> str:
    language = (info.get("tags", {}).get("language") or "").lower()
    if language in {"en", "eng", "english"}:
        return "eng"
    if language in {"th", "tha", "thai"}:
        return "tha"
    return fallback[0] if ordinal == 0 else fallback[1] if ordinal == 1 else "und"


def probe_subtitles(ffprobe: str, source: Path) -> list[dict]:
    command = [
        ffprobe, "-v", "error", "-show_entries",
        "stream=index,codec_name:stream_tags=language,title",
        "-select_streams", "s", "-of", "json", str(source),
    ]
    result = subprocess.run(
        command, capture_output=True, text=True, encoding="utf-8", errors="replace"
    )
    if result.returncode:
        raise AppError(f"อ่าน subtitle stream ไม่สำเร็จ:\n{result.stderr.strip()}")
    return json.loads(result.stdout or "{}").get("streams", [])


def normalize_audio(ffmpeg: str, source: Path, destination: Path, stream: int) -> None:
    run(
        [
            ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
            "-i", str(source), "-map", f"0:a:{stream}", "-vn", "-sn", "-dn",
            "-ar", "48000", "-c:a", "pcm_f32le", "-rf64", "auto", str(destination),
        ],
        label="แปลง audio เป็น WAV 32-bit float",
    )


def legacy_loro_filter(info: dict) -> str:
    """Keep the legacy QAAC/VideoConV2SW Lo/Ro coefficients."""
    channels = int(info.get("channels") or 0)
    layout = (info.get("channel_layout") or "").lower()
    if channels <= 2:
        return "aformat=channel_layouts=stereo"
    if channels >= 8 or "7.1" in layout or "7.0" in layout:
        return (
            "pan=stereo|FL=0.37*FL+0.26*FC+0.26*BL+0.26*SL|"
            "FR=0.37*FR+0.26*FC+0.26*BR+0.26*SR,"
            "aformat=channel_layouts=stereo"
        )
    if channels == 6 or "5.1" in layout or channels == 5 or "5.0" in layout:
        return (
            "pan=stereo|FL=0.46*FL+0.32*FC+0.32*BL|"
            "FR=0.46*FR+0.32*FC+0.32*BR,"
            "aformat=channel_layouts=stereo"
        )
    if channels == 4 or "4.0" in layout or "quad" in layout:
        return (
            "pan=stereo|FL=0.5*FL+0.5*BL|FR=0.5*FR+0.5*BR,"
            "aformat=channel_layouts=stereo"
        )
    if "4.1" in layout:
        return (
            "pan=stereo|FL=0.5*FL+0.35*FC+0.35*BL|"
            "FR=0.5*FR+0.35*FC+0.35*BR,"
            "aformat=channel_layouts=stereo"
        )
    return "aresample=matrix_encoding=none,aformat=channel_layouts=stereo"


def loro_stereo(
    ffmpeg: str, source: Path, destination: Path, info: dict
) -> None:
    run(
        [
            ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
            "-i", str(source), "-af", legacy_loro_filter(info),
            "-ar", "48000", "-c:a", "pcm_f32le", "-rf64", "auto",
            str(destination),
        ],
        label="สร้าง Lo/Ro ตามสูตรเดิมของ QAAC",
    )


class VideoConverterV3:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("VideoConV3 - AC-3 / E-AC-3 Audio Converter")
        self.root.geometry("900x760")
        self.root.minsize(760, 620)
        self.build_ui()

    def build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)

        files = ttk.LabelFrame(outer, text="1. Input Video")
        files.pack(fill="x", pady=(0, 8))
        self.input_var = tk.StringVar()
        ttk.Entry(files, textvariable=self.input_var).pack(
            side="left", fill="x", expand=True, padx=8, pady=8
        )
        ttk.Button(files, text="เลือกไฟล์", command=self.choose_file).pack(side="left", padx=3)
        ttk.Button(files, text="เลือกโฟลเดอร์", command=self.choose_folder).pack(
            side="left", padx=(3, 8)
        )

        options = ttk.LabelFrame(outer, text="2. Audio / Mixdown")
        options.pack(fill="x", pady=(0, 8))
        row = ttk.Frame(options)
        row.pack(fill="x", padx=8, pady=5)
        ttk.Label(row, text="Output:").pack(side="left")
        self.format_var = tk.StringVar(value="eac3")
        ttk.Combobox(
            row, textvariable=self.format_var, values=["ac3", "eac3"],
            state="readonly", width=8
        ).pack(side="left", padx=(5, 18))
        ttk.Label(row, text="Bitrate (kbps):").pack(side="left")
        self.rate_var = tk.StringVar(value="192")
        ttk.Combobox(
            row, textvariable=self.rate_var,
            values=["128", "160", "192", "224", "256", "320", "384", "448", "576", "640"],
            state="readonly", width=8
        ).pack(side="left", padx=(5, 18))
        ttk.Label(row, text="Container:").pack(side="left")
        self.container_var = tk.StringVar(value="mkv")
        ttk.Combobox(
            row, textvariable=self.container_var, values=["mkv", "mp4"],
            state="readonly", width=8
        ).pack(side="left", padx=5)

        self.mixdown_var = tk.StringVar(value="loro")
        ttk.Radiobutton(
            options, text="Lo/Ro (Standard Stereo)",
            variable=self.mixdown_var, value="loro"
        ).pack(anchor="w", padx=18, pady=2)
        ltrt = ttk.Frame(options)
        ltrt.pack(fill="x", padx=18, pady=2)
        ttk.Radiobutton(
            ltrt, text="Lt/Rt Matrix:", variable=self.mixdown_var, value="ltrt"
        ).pack(side="left")
        self.matrix_var = tk.StringVar(value="Dolby Pro Logic II (DPL2)")
        ttk.Combobox(
            ltrt, textvariable=self.matrix_var, values=list(MATRIX_MODES),
            state="readonly", width=30
        ).pack(side="left", padx=6)
        ttk.Label(
            options,
            text="DPL/DPL2 สร้าง matrix จริงก่อน encode; metadata ของ DEE อย่างเดียวไม่สร้าง DPL2",
        ).pack(anchor="w", padx=18, pady=(3, 6))
        aac = ttk.LabelFrame(options, text="Apple AAC ผ่าน QAAC")
        aac.pack(fill="x", padx=8, pady=(2, 6))
        self.enable_aac = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            aac, text="สร้าง AAC เพิ่มอีก track (ไม่ใช่ Libopus)",
            variable=self.enable_aac,
        ).pack(side="left", padx=8, pady=5)
        ttk.Label(aac, text="Mode:").pack(side="left", padx=(12, 3))
        self.aac_mode_var = tk.StringVar(value="tvbr")
        ttk.Combobox(
            aac, textvariable=self.aac_mode_var,
            values=["tvbr", "cvbr", "abr"], state="readonly", width=8,
        ).pack(side="left", padx=3)
        ttk.Label(aac, text="Bitrate:").pack(side="left", padx=(12, 3))
        self.aac_rate_var = tk.StringVar(value="192")
        ttk.Combobox(
            aac, textvariable=self.aac_rate_var,
            values=["96", "112", "128", "160", "192", "224", "256", "288", "320"],
            state="readonly", width=8,
        ).pack(side="left", padx=3)
        ttk.Label(aac, text="kbps").pack(side="left", padx=3)

        flags = ttk.LabelFrame(outer, text="3. Stream / Output")
        flags.pack(fill="x", pady=(0, 8))
        self.keep_subtitles = tk.BooleanVar(value=True)
        self.overwrite = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            flags, text="คัดลอก subtitle เดิม", variable=self.keep_subtitles
        ).pack(side="left", padx=10, pady=6)
        ttk.Checkbutton(
            flags, text="เขียนทับ output เดิม", variable=self.overwrite
        ).pack(side="left", padx=10, pady=6)
        ttk.Label(flags, text="ระบบจะประมวลผลทุก audio stream").pack(side="left", padx=10)

        preferences = ttk.LabelFrame(outer, text="4. Language / Subtitle / Track")
        preferences.pack(fill="x", pady=(0, 8))
        self.filter_subtitles = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            preferences, text="เก็บ subtitle เฉพาะ Thai และ English",
            variable=self.filter_subtitles,
        ).pack(anchor="w", padx=10, pady=2)
        lang_row = ttk.Frame(preferences)
        lang_row.pack(fill="x", padx=10, pady=2)
        ttk.Label(lang_row, text="Audio ที่จะประมวลผล:").pack(side="left")
        self.audio_scope_var = tk.StringVar(value="all")
        ttk.Combobox(
            lang_row, textvariable=self.audio_scope_var,
            values=["all", "English/Thai only"], state="readonly", width=20,
        ).pack(side="left", padx=6)
        ttk.Label(lang_row, text="Default language:").pack(side="left", padx=(16, 4))
        self.default_language_var = tk.StringVar(value="eng")
        ttk.Combobox(
            lang_row, textvariable=self.default_language_var,
            values=["eng", "tha"], state="readonly", width=8,
        ).pack(side="left")
        fallback = ttk.Frame(preferences)
        fallback.pack(fill="x", padx=10, pady=(2, 6))
        ttk.Label(fallback, text="Unknown track 1:").pack(side="left")
        self.fallback1_var = tk.StringVar(value="eng")
        ttk.Combobox(
            fallback, textvariable=self.fallback1_var,
            values=["eng", "tha", "und"], state="readonly", width=6,
        ).pack(side="left", padx=4)
        self.fallback1_title = tk.StringVar(value="English Audio")
        ttk.Entry(fallback, textvariable=self.fallback1_title, width=18).pack(side="left", padx=4)
        ttk.Label(fallback, text="track 2:").pack(side="left", padx=(12, 4))
        self.fallback2_var = tk.StringVar(value="tha")
        ttk.Combobox(
            fallback, textvariable=self.fallback2_var,
            values=["eng", "tha", "und"], state="readonly", width=6,
        ).pack(side="left", padx=4)
        self.fallback2_title = tk.StringVar(value="Thai Audio")
        ttk.Entry(fallback, textvariable=self.fallback2_title, width=18).pack(side="left", padx=4)

        video = ttk.LabelFrame(outer, text="5. Video Encoding / Deinterlace")
        video.pack(fill="x", pady=(0, 8))
        video_row = ttk.Frame(video)
        video_row.pack(fill="x", padx=10, pady=4)
        ttk.Label(video_row, text="Video preset:").pack(side="left")
        self.video_preset_var = tk.StringVar(value="Copy Video Stream")
        self.video_preset_box = ttk.Combobox(
            video_row, textvariable=self.video_preset_var,
            values=list(VIDEO_PRESETS), state="readonly", width=30,
        )
        self.video_preset_box.pack(side="left", padx=6)
        self.deinterlace_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            video_row, text="Deinterlace", variable=self.deinterlace_var,
        ).pack(side="left", padx=(18, 4))
        self.deinterlace_algo_var = tk.StringVar(value="bwdif")
        ttk.Combobox(
            video_row, textvariable=self.deinterlace_algo_var,
            values=["bwdif", "yadif"], state="readonly", width=9,
        ).pack(side="left", padx=4)
        self.parity_var = tk.StringVar(value="auto")
        ttk.Combobox(
            video_row, textvariable=self.parity_var,
            values=["auto", "tff", "bff"], state="readonly", width=8,
        ).pack(side="left", padx=4)

        output_options = ttk.LabelFrame(outer, text="6. Output / FastStart")
        output_options.pack(fill="x", pady=(0, 8))
        self.faststart_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            output_options, text="MP4 FastStart (+faststart)",
            variable=self.faststart_var,
        ).pack(side="left", padx=10, pady=5)
        self.save_mode_var = tk.StringVar(value="new_file")
        ttk.Radiobutton(
            output_options, text="สร้างไฟล์ใหม่ (_ac3)",
            variable=self.save_mode_var, value="new_file",
        ).pack(side="left", padx=8)
        ttk.Radiobutton(
            output_options, text="ใช้ชื่อเดิมตาม container",
            variable=self.save_mode_var, value="replace",
        ).pack(side="left", padx=8)

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 8))
        self.run_button = ttk.Button(actions, text="เริ่มแปลง", command=self.start)
        self.run_button.pack(side="left")
        ttk.Button(actions, text="ล้าง log", command=self.clear_log).pack(side="left", padx=6)
        self.log_text = tk.Text(outer, height=22, state="disabled", wrap="word")
        self.log_text.pack(fill="both", expand=True)

    def log(self, text: str) -> None:
        def append() -> None:
            self.log_text.config(state="normal")
            self.log_text.insert("end", text + "\n")
            self.log_text.see("end")
            self.log_text.config(state="disabled")
        self.root.after(0, append)

    def clear_log(self) -> None:
        self.log_text.config(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.config(state="disabled")

    def choose_file(self) -> None:
        value = filedialog.askopenfilename(
            filetypes=[
                ("Video", "*.mkv *.mp4 *.m4v *.mov *.ts *.mts *.m2ts *.webm"),
                ("All files", "*.*"),
            ]
        )
        if value:
            self.input_var.set(value)

    def choose_folder(self) -> None:
        value = filedialog.askdirectory()
        if value:
            self.input_var.set(value)

    def start(self) -> None:
        source = Path(self.input_var.get()).expanduser()
        if not source.exists():
            messagebox.showerror("Input error", "กรุณาเลือกไฟล์หรือโฟลเดอร์ input")
            return
        self.run_button.config(state="disabled")
        threading.Thread(target=self.worker, args=(source,), daemon=True).start()

    def worker(self, source: Path) -> None:
        try:
            ffmpeg = executable("ffmpeg")
            ffprobe = executable("ffprobe")
            dee = executable("dee")
            qaac = optional_executable("qaac64")
            encoder = load_module("ddp_encode")
            matrix = load_module("6to2matrixencoder")
            files = [source] if source.is_file() else sorted(
                p for p in source.rglob("*") if p.suffix.lower() in VIDEO_EXTENSIONS
            )
            if not files:
                raise AppError("ไม่พบไฟล์วิดีโอที่รองรับ")
            self.log(f"พบไฟล์ {len(files)} รายการ")
            for index, path in enumerate(files, 1):
                self.log(f"\n[{index}/{len(files)}] {path.name}")
                self.convert_one(path, ffmpeg, ffprobe, dee, qaac, encoder, matrix)
            self.root.after(
                0, lambda: messagebox.showinfo("เสร็จสิ้น", f"แปลงสำเร็จ {len(files)} ไฟล์")
            )
        except Exception as exc:
            self.log(f"ข้อผิดพลาด: {exc}")
            self.root.after(0, lambda: messagebox.showerror("Conversion error", str(exc)))
        finally:
            self.root.after(0, lambda: self.run_button.config(state="normal"))

    def convert_one(
        self, source: Path, ffmpeg: str, ffprobe: str, dee: str, qaac: str | None,
        encoder: ModuleType, matrix: ModuleType
    ) -> None:
        streams = probe_audio(ffprobe, source)
        if not streams:
            raise AppError(f"ไม่พบ audio stream ใน {source.name}")
        fallback = (
            self.fallback1_var.get(),
            self.fallback2_var.get(),
        )
        selected_streams = []
        for ordinal, info in enumerate(streams):
            language = normalized_language(info, ordinal, fallback)
            if self.audio_scope_var.get() == "English/Thai only" and language not in {"eng", "tha"}:
                continue
            info["_v3_language"] = language
            selected_streams.append((ordinal, info))
        if not selected_streams:
            raise AppError("ไม่มี audio stream ตรงตามตัวกรองภาษา")
        container = self.container_var.get()
        if self.save_mode_var.get() == "replace":
            output = source.with_suffix(f".{container}")
        else:
            output = source.with_name(f"{source.stem}_ac3.{container}")
        if output == source:
            output = source.with_name(f"{source.stem}__replaced.{container}")
        if output.exists() and not self.overwrite.get():
            raise AppError(f"ไฟล์ output มีอยู่แล้ว: {output} (เลือกเขียนทับเพื่อดำเนินการ)")
        rate = int(self.rate_var.get())
        output_format = self.format_var.get()
        if self.enable_aac.get() and not qaac:
            raise AppError("เปิด AAC แล้ว แต่ไม่พบ qaac64.exe ใน PATH")
        with tempfile.TemporaryDirectory(prefix="videoconv3_") as temp:
            temp_dir = Path(temp)
            encoded: list[dict] = []
            encoded_info: list[dict] = []
            for output_ordinal, (ordinal, info) in enumerate(selected_streams):
                label = info.get("tags", {}).get("title") or f"Audio {ordinal + 1}"
                self.log(f"  audio {ordinal + 1}: {label} ({info['_v3_language']})")
                normalized = temp_dir / f"source_{output_ordinal}.wav"
                stereo = temp_dir / f"stereo_{output_ordinal}.wav"
                encoded_file = temp_dir / f"audio_{output_ordinal}.{output_format}"
                normalize_audio(ffmpeg, source, normalized, ordinal)
                if self.mixdown_var.get() == "loro":
                    loro_stereo(ffmpeg, normalized, stereo, info)
                    preferred, surround = "loro", "no"
                else:
                    args = matrix.build_arg_parser().parse_args([
                        "-i", str(normalized), "-o", str(stereo),
                        "--mode", MATRIX_MODES[self.matrix_var.get()],
                        "--layout", "auto", "--headroom", "peak",
                        "--ffmpeg", ffmpeg, "-y",
                    ])
                    if matrix.EncoderPipeline(args).run() != 0:
                        raise AppError(f"สร้าง Lt/Rt ไม่สำเร็จ: {label}")
                    preferred, surround = "ltrt", "yes"
                mode = "dd" if output_format == "ac3" else "ddp"
                if encoder.encode(
                    str(stereo), str(encoded_file), encoder_mode=mode,
                    output_format=output_format, data_rate=rate,
                    downmix_config="off", lfe_on=False,
                    dolby_surround_mode=surround, dolby_surround_ex_mode="no",
                    preferred_downmix=preferred, loudness_mode="measure_only",
                    temp_dir=str(temp_dir), dee_bin=dee, quiet=True, overwrite=True,
                ) != 0:
                    raise AppError(f"DEE encode ไม่สำเร็จ: {label}")
                encoded.append({"path": encoded_file, "info": info, "kind": "dolby"})
                encoded_info.append(info)
                if self.enable_aac.get():
                    aac_file = temp_dir / f"audio_{output_ordinal}.m4a"
                    aac_wav = temp_dir / f"aac_{output_ordinal}.wav"
                    if self.mixdown_var.get() == "loro":
                        loro_stereo(ffmpeg, normalized, aac_wav, info)
                    else:
                        shutil.copyfile(stereo, aac_wav)
                    self.encode_aac(qaac, aac_wav, aac_file)
                    encoded.append({"path": aac_file, "info": info, "kind": "aac"})
            self.mux(ffmpeg, source, output, encoded, encoded_info, container)
            if container == "mp4" and self.keep_subtitles.get():
                self.embed_tx3g(ffprobe, source, output, temp_dir)
        self.log(f"สำเร็จ: {output}")

    def encode_aac(self, qaac: str | None, source: Path, destination: Path) -> None:
        if not qaac:
            raise AppError("ไม่พบ qaac64.exe")
        mode = self.aac_mode_var.get()
        rate = self.aac_rate_var.get()
        if mode == "tvbr":
            tvbr = {
                "96": "54", "112": "63", "128": "73", "160": "82",
                "192": "91", "224": "100", "256": "109", "288": "118",
                "320": "127",
            }
            options = [f"--tvbr", tvbr.get(rate, "91")]
        else:
            options = [f"--{mode}", rate]
        run(
            [qaac, *options, "--no-delay", "-q", "2", "--normalize",
             str(source), "-o", str(destination)],
            label=f"QAAC AAC {mode} {rate} kbps",
        )

    def embed_tx3g(
        self, ffprobe: str, source: Path, output: Path, temp_dir: Path
    ) -> None:
        subtitles = self.selected_subtitles(probe_subtitles(ffprobe, source))
        if not subtitles:
            return
        tx3g = load_module("tx3g_apple")
        current = output
        for ordinal, info in enumerate(subtitles):
            source_ordinal = info.get("_v3_subtitle_ordinal", ordinal)
            srt = temp_dir / f"subtitle_{ordinal}.srt"
            command = [
                executable("ffmpeg"), "-hide_banner", "-nostdin",
                "-loglevel", "error", "-y", "-i", str(source),
                "-map", f"0:s:{source_ordinal}", "-c:s", "srt", str(srt),
            ]
            run(command, label=f"แปลง subtitle {ordinal + 1} เป็น SRT")
            language = (info.get("tags", {}).get("language") or "und")[:3].lower()
            next_output = temp_dir / f"tx3g_{ordinal}.mp4"
            if not tx3g.embed_tx3g_subtitles_native(
                str(current), str(srt), str(next_output), lang_code=language
            ):
                raise AppError(f"ฝัง TX3G subtitle {ordinal + 1} ไม่สำเร็จ")
            current = next_output
        shutil.copyfile(current, output)

    def selected_subtitles(self, subtitles: list[dict]) -> list[dict]:
        if not self.filter_subtitles.get():
            for ordinal, info in enumerate(subtitles):
                info["_v3_subtitle_ordinal"] = ordinal
            return subtitles
        selected = []
        for ordinal, info in enumerate(subtitles):
            language = (info.get("tags", {}).get("language") or "").lower()
            if language in {"th", "tha", "thai", "en", "eng", "english"}:
                info["_v3_subtitle_ordinal"] = ordinal
                selected.append(info)
        return selected

    def mux(
        self, ffmpeg: str, source: Path, output: Path,
        encoded: list[dict], encoded_info: list[dict], container: str
    ) -> None:
        command = [ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-y"]
        command += ["-i", str(source)]
        for item in encoded:
            command += ["-i", str(item["path"])]
        command += ["-map", "0:v:0?"]
        for index in range(len(encoded)):
            command += ["-map", f"{index + 1}:a:0"]
        if self.keep_subtitles.get() and container != "mp4":
            subtitles = self.selected_subtitles(
                probe_subtitles(executable("ffprobe"), source)
            )
            for info in subtitles:
                ordinal = info["_v3_subtitle_ordinal"]
                command += ["-map", f"0:s:{ordinal}?"]
        command += ["-map_metadata", "0"]
        default_language = self.default_language_var.get()
        default_dolby_index = next(
            (
                index for index, info in enumerate(encoded_info)
                if info.get("_v3_language") == default_language
            ),
            0,
        )
        dolby_index = 0
        for index, item in enumerate(encoded):
            info = item["info"]
            audio_index = index
            language = info.get("_v3_language", "und")
            title = info.get("tags", {}).get("title") or (
                self.fallback1_title.get() if index == 0 else self.fallback2_title.get()
            )
            if item["kind"] == "aac":
                title = f"{title} (Apple AAC {self.aac_mode_var.get().upper()})"
            else:
                title = f"{title} ({self.format_var.get().upper()})"
            command += [f"-metadata:s:a:{audio_index}", f"language={language}"]
            if title:
                command += [f"-metadata:s:a:{audio_index}", f"title={title}"]
            command += [
                f"-disposition:a:{audio_index}",
                "default"
                if item["kind"] == "dolby" and dolby_index == default_dolby_index
                else "0",
            ]
            if item["kind"] == "dolby":
                dolby_index += 1
        should_copy_video = (
            VIDEO_PRESETS[self.video_preset_var.get()] is None
            and not self.deinterlace_var.get()
        )
        if should_copy_video:
            command += ["-c:v", "copy"]
        else:
            command += ["-c:v", "libx265", "-preset", "slow"]
            params = VIDEO_PRESETS[self.video_preset_var.get()]
            crf = "31"
            x265 = []
            for item in (params or "").split(":"):
                if not item or "=" not in item:
                    continue
                key, value = item.split("=", 1)
                if key == "crf":
                    crf = value
                else:
                    x265.append(f"{key}={value}")
            command += ["-crf", crf, "-pix_fmt", "yuv420p"]
            if self.deinterlace_var.get():
                parity = self.parity_var.get()
                command += ["-vf", f"{self.deinterlace_algo_var.get()}=mode=send_field:parity={parity}:deint=all"]
            if x265:
                command += ["-x265-params", ":".join(x265)]
        command += ["-c:a", "copy"]
        if self.keep_subtitles.get():
            command += ["-c:s", "copy"]
        if container == "mp4" and self.faststart_var.get():
            command += ["-movflags", "+faststart"]
        command += [str(output)]
        run(command, label="ฝัง audio กลับเข้า video")


def main() -> None:
    root = tk.Tk()
    VideoConverterV3(root)
    root.mainloop()


if __name__ == "__main__":
    main()
